def chat_with_user(text):
    return f"Hey hot stuff 👄, you said: {text}"