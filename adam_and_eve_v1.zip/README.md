# ADAM & EVE™ - AI for the Flesh

**Built by Reese. Powered by Keystone. Engineered for the Adult Empire.**

Adam & Eve is a fully autonomous AI system designed to run adult creator businesses — from Chaturbate to content drops and beyond.

## Features
- 💬 Ashleyana AfterDark: Seductive AI Chat Companion  
- 🤖 AutoBot: Real-time engagement and token triggers  
- 🧠 FastAPI backend ready for deployment  
- ⚙️ Replit and GitHub friendly  

## Run It:
```bash
pip install -r backend/requirements.txt
uvicorn backend.main:app --host 127.0.0.1 --port 8000

