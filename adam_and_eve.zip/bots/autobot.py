def start_autobot(model_name):
    return {"status": "running", "model": model_name}